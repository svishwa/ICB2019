
To make a sample ICB 2019 paper, copy the contents of this directory
somewhere, and type

 latex egpaper_for_review

or 

 pdflatex egpaper_for_review


